function MSG(intent, value) {
    return {
        intent: intent,
        value: value
    };
}
